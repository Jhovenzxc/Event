<html>
<style>
body {font-family: sans-serif;}

button#Bday {
}
button#Baptism {
}
button#Wedding {
}
button#Halloween {
}

/* School Events*/
button#Acquaintance {
}
button#Grandball {
}
button#ChristmasPasrty {
}



body  {
    background-image: url("Background-1.jpg");
    background-color: #cccccc;
}
p {
	color: White;
	text-align: center;
	}
header {
	background-image: url('background1.jpg');
	background-position: top ;
    padding: 1em;
    color: white;
    clear: left;
	text-align: center;
    background-color: yellow;
    box-shadow: 9px 9px 6px red;
}

footer {
	background-position: top ;
    padding: 1em;
    color: white;
    clear: left;
	text-align: center;
}
	 
ul.tab {
    list-style-type: none;
    margin: 1;
    padding: 2;
    overflow: hidden;
    border: 15px solid #ccc;
    background-color: #666;
}

/* Float the list items side by side */
ul.tab li {float: left;}

/* Style the links inside the list items */
ul.tab li a {
    display: inline-block;
    color: Black;
    text-align: center;
    padding: 19px 39.9px;
    text-decoration: none;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of links on hover */
ul.tab li a:hover {
    background-color: #aaa;
}

/* Create an active/current tablink class */
ul.tab li a:focus, .active {
    background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style>
<body>

<header> 
<font face="snap itc" size="10" >
<i><b> EVENT PLANNER </b></i>
</font face="Time New Roman" size="10" >
</header> <br>




<ul class="tab">
  <li>
  <a href="#" class="tablinks" onclick="EventPlan(event, 'Home')">
  <b>
  <font face="Time New Roman" size="5">
  Home
  </font face="Time New Roman" size="5" >
  </b>
  </a>

  </li>
  
  <li>
  <a href="#" class="tablinks" onclick="EventPlan(event, 'Introduction')">
  <font face="Time New Roman" size="5">
  <b>
  Introduction
  </b>

  </font face="Time New Roman" size="5" >
  </a>
  </li>  
  
  <li>
  <li>
  <a href="#" class="tablinks" onclick="EventPlan(event, 'Local Events')">
  <font face="Time New Roman" size="5">
  <b>
  Local Events
  </b>
  </font face="Time New Roman" size="5" >
  </a>
  </li>  

  <li>
  <a href="#" class="tablinks" onclick="EventPlan(event, 'School Events')">
  <font face="Time New Roman" size="5">
  <b>
  School Events
  </b>
  </font face="Time New Roman" size="5" >
  </a>
  </li> 
  
  <li>
  <a href="#" class="tablinks" onclick="EventPlan(event, 'Contact')">
  <font face="Time New Roman" size="5">
  <b>
  Contact
  </b>
  </font face="Time New Roman" size="5" >
  </a>
  </li> 
  

</ul>

  
  
  
<div id="Home" class="tabcontent">
<p>
<font face="Lucida handwriting" size="6.8" >
<b>Hello!<br> We are your Event Planner partner.<br>
We will give you an additional ideas about your chosen event and we will sure that your event goes by your own decision.
</b></font face="Time New Roman" size="22" >
<p>
</div>


<div id="Introduction" class="tabcontent">
<p>  <font face="Time New Roman" size="6" color="white">
<b>Event Planning</b> <br>
<q>Before you attempt to manage another event, especially a big one, there are a number of questions that need to be asked. These tips provide an introduction to the event planning process and will enable anyone to manage and plan events of all sizes - from the very first steps, to the actual event itself.  </q><br>
What are you doing this for?<br>
<q>One of the keys to working on any event is to ask the fundamental question    <q>what is this event for?</q> Now this may seem like a stupid question - isn’t it obvious what the event is for? - Well no, not always. The best way to organize an outstanding event, is to ask some outstanding questions. Now, some events are organized ‘in-house’ (where the people who want and need the event are the same as those organizing it) and others are organized by external event planners or managers, from an event management agency. No matter who the event is for, it is critical that all of those involved, from the managers to the receptionist, know what the event is for.<br></q>
Why is this important?<br>
<q>It is important to understand the reason for the event so that everyone knows what the needs of the event are going to be. The needs of the event will include all elements of the event planning process - from the beginning to the end - as well as external elements, such as marketing, finance, technology and human resources.
It is also important that the event needs are written down and kept as guidelines for all those involved. Many event projects take place over several months, and it can often be that the original need for the event can be lost as the project gathers momentum.
By establishing your desired outcome, you will help yourself to identify and answer some of the most important factors and questions relating to the event.
For example, the desired outcome of a music event (such as the world famous Glastonbury Festival) will be very different to that of a charity ball, or a sales conference, or a sports event.
Once you know what you want from your event, it will help you to decide the focus of the event. This will again, help to focus the team whilst the planning is undertaken. For example, when planning a fundraising event, the focus might be to raise funds then and there on the night of the event - but if you also want to raise awareness of the charity - you may wish to consider ways of persuading the guests to make donations in the days and weeks that follow.
The focus of your event must be the key driver in everything that you do for the event, the choice of venue, content and guest speaker (to name but a very few) should reflect this - even your choice of menu, use of technology and theme should be focused in this way.</q>
What can you do?<br>
<q>To establish a focus, brainstorm the event with your colleagues, clients - anyone who can give an insight into the need for the event. A sales conference might have a need to communicate a new product - and at the same time, be needed to enthuse and motivate a sales team. Look at the event from all aspects - including those of the attendees, managers, planners, venue and suppliers and try to get an overall understanding of the needs of each of these groups.
To get the most from this focus - print it onto a piece of paper and stick it to the wall beside your desk - in fact - stick it to the wall by the desk of each person who is working on the event. Why not make this focus the screensaver on your computer - the old adage is true - an aim is worthless unless it is written down. Let this focus your mind, your ideas and your event so that everyone receives the same message - the most important message - from the event.
</p>
If you are working in an external event planning agency, and the event is on behalf of a client - then it is even more important that the event planning team have a deep understanding of the needs of the event - in order that the client gets the event that they want. This is a two-way responsibility - the client should tell you their requirements - but it is a key responsibility of yours - to ask. It is more important because you are removed from the focus of the client organisation - your focus might be to offer an excellent service to the client, or to bring the event in on budget - but remember, this is NOT the focus of the event.</q>
</div>


<div id="Local Events" class="tabcontent">



<h3><center> Birthday </h3>
<center><button id="Bday">
<a href="#">
Press here!
</a>
</button></center>

<h3><center>Wedding</h3>
<center><button id="Wedding">
<a href="#">
Press here!
</a>
</button></center>

<h3><center>Halloween</h3>
<center><button id="Halloween">
<a href="#">
Press here!
</a>
</button></center>
   
<h3><center>Baptism</h3>
<button id="Baptism">
<a href="#">
Press here!
</a>
</button></center>
</div>


<div id="School Events" class="tabcontent">



<h3><center> Acquaintance </h3>
<center><button id="Acquaintance">
<a href="#">
Press here!
</a>
</button></center>

<h3><center> Grandball</h3>
<center><button id="Grandball">
<a href="#">
Press here!
</a>
</button></center>

<h3><center>Christmas Party</h3>
<center><button id="Christmas Party">
<a href="#">
Press here!
</a>
</button></center>
</div>


<div id="Contact" class="tabcontent">
<p>  <font face="Aharoni" size="6" color="white">
Contact us now via: <br>
Email: EventPlanner@yahoo.com <br>
Facebook: Www.facebook.com/EventPlanner <br>
Phone: 0989314789234789 <br> <br> <br>
Thank you for FUCKING! .,/,.
</p>






<script>
function EventPlan(event, eventName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(eventName).style.display = "block";
    evt.currentTarget.className += "active";
}
</script>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

 
 
<footer>
<font face="Time New Roman" size="3" >
Copyright
</font face="Time New Roman" size="3" >
</footer> <br>
	 
	 
	 
	 
	 
</body>