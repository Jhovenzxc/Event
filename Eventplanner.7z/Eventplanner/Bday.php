<html>
<style>

body  {
    background-image: url("background1.jpg");
    background-color: #cccccc;
}
p {
	color: White;
	text-align: center;
	}
header {
	background-image: url('background1.jpg');
	background-position: top ;
    padding: 1em;
    color: white;
    clear: left;
	text-align: center;
    background-color: yellow;
    box-shadow: 9px 9px 6px red;
}

footer {
	background-position: top ;
    padding: 1em;
    color: white;
    clear: left;
	text-align: center;
}

<body>
startloop: <input type="text" name="Strlp"/>
endloop: <input type="text" name="endloop"/>
<input type="submit"/>
</body>





</body>
</html>