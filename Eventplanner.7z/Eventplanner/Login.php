<html>
<style>

body  {
    background-image: url("background1.jpg");
    background-color: #cccccc;
}
p {
		text-align: center;
}
button#c v76  {
}
</style>
<body>
<p>
Name : <input type="text" name="FName">
<br>
Age : <input type="text" name="Age">
<br>
<input type="Submit">
</p>
</body>
</html>                                                                                                                                                                                                                                                                                                                                                                                        